const express = require("express");
const { listenerCount } = require("process");
const server = express();

server.get("/", (req,res)=>
{
    return res.json ({mensagem:("Ta funcionando porra")})
}
)

server.get("/ping",(req,res)=>{
    return res.json("pong")
})

server.get("/pong",(req,res)=>{
    return res.json("ping")
})

server.listen(3000,()=>{
    console.log("Servidor Funcionando")
});